# test_self_play.py
from alphazero_agent import AlphaZeroAgent
from collections import deque

def test_self_play():
    state_dim = 42  # 6 rows * 7 columns
    action_dim = 7  # Number of columns in Connect Four
    agent = AlphaZeroAgent(state_dim=state_dim, action_dim=action_dim, use_gpu=False)
    
    # Optionally load a pre-trained model
    # agent.load_model("alphazero_model_final.pth")
    
    # Perform a self-play game
    agent.self_play()
    
    # Inspect a snippet of the memory
    if agent.memory:
        state, mcts_prob, value = agent.memory[0]
        print("Sample Training Data:")
        print("State:\n", state)
        print("MCTS Probabilities:", mcts_prob)
        print("Value:", value)
    else:
        print("No training data collected.")

if __name__ == "__main__":
    test_self_play()