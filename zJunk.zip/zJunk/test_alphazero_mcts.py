# test_alphazero_mcts.py

import numpy as np
import torch
from alphazero_agent import AlphaZeroAgent
from connect4 import Connect4

def test_immediate_win():
    # Initialize the game environment and agent
    env = Connect4()
    agent = AlphaZeroAgent(state_dim=42, action_dim=7, use_gpu=False)

    # Load the trained model
    try:
        agent.load_model("alphazero_model_final.pth")
        print("Model loaded successfully.")
    except FileNotFoundError:
        print("Trained model not found. Please ensure 'alphazero_model_final.pth' exists.")
        return

    # Set up a board state where the agent (Player 1) has an immediate winning move in column 3
    env.board = np.array([
        [0, 0, 0, 0, 0, 0, 0],  # Row 0 (top of the board)
        [0, 0, 0, 0, 0, 0, 0],  # Row 1
        [0, 0, 0, 0, 0, 0, 0],  # Row 2
        [2, 1, 1, 0, 0, 0, 0],  # Row 3
        [1, 2, 2, 0, 0, 0, 0],  # Row 4
        [1, 1, 2, 0, 0, 0, 0],  # Row 5 (bottom of the board)
    ], dtype=np.int8)
    env.current_player = 1  # It's Player 1's (agent's) turn
    agent.current_player = env.current_player  # Update agent's current player

    # Perform MCTS simulations
    selected_action, actions, probabilities = agent.mcts_simulate(env.board, env, num_simulations=800)

    # Output the policy probabilities
    print(f"Actions: {actions}")
    print(f"Probabilities: {probabilities}")

    # Get policy and value from the neural network
    state_tensor = agent.preprocess(env.board * env.current_player)
    log_policy, value = agent.model(state_tensor)
    policy_probs = torch.exp(log_policy).detach().numpy().flatten()
    print(f"Neural network policy probabilities: {policy_probs}")
    print(f"Neural network value prediction: {value.item()}")

    # Check if the agent selects the immediate winning move
    print(f"Selected action: {selected_action}")
    if selected_action == 3:
        print("Test passed: Agent selected the immediate winning move.")
    else:
        print("Test failed: Agent did not select the immediate winning move.")

if __name__ == "__main__":
    test_immediate_win()