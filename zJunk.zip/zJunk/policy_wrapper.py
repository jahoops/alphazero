# policy_wrapper.py

import torch.nn as nn

class PolicyModelWrapper(nn.Module):
    def __init__(self, model):
        super(PolicyModelWrapper, self).__init__()
        self.model = model

    def forward(self, x):
        # Get the policy output from the model
        policy, _ = self.model(x)
        print(f"Policy output shape: {policy.shape}")
        return policy