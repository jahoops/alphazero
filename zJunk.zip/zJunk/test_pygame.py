import pygame
import time

def test_pygame_window():
    pygame.init()
    screen = pygame.display.set_mode((640, 480))
    pygame.display.set_caption("Pygame Test Window")
    
    running = True
    start_time = time.time()
    
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        
        # Close the window after 5 seconds
        if time.time() - start_time > 5:
            running = False
        
        screen.fill((0, 0, 0))  # Fill the screen with black
        pygame.display.flip()  # Update the display
    
    pygame.quit()

if __name__ == "__main__":
    test_pygame_window()