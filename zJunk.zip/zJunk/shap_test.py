# shap_test.py

import torch
import shap
import numpy as np
from alphazero_agent import AlphaZeroAgent  # Import AlphaZeroAgent for model access
from policy_wrapper import PolicyModelWrapper  # Import the wrapper model
from torchsummary import summary  # Import torchsummary

# Load your dataset
X_train = np.load('X_train.npy')  # Load from a NumPy file

# Verify the shape of X_train
print(f"Original X_train shape: {X_train.shape}")

# Reshape X_train to match the model's expected input shape
# Assuming X_train is (num_samples, 6, 7), add a channel dimension
X_train = X_train.reshape(-1, 1, 6, 7)  # New shape: (num_samples, 1, 6, 7)
print(f"Reshaped X_train shape: {X_train.shape}")

# Initialize the AlphaZeroAgent with required arguments
state_dim = 42  # Define the state dimension based on your setup
action_dim = 7  # Define the action dimension based on your setup
agent = AlphaZeroAgent(state_dim=state_dim, action_dim=action_dim, use_gpu=False)

# Load the trained model using AlphaZeroAgent's method
model_path = 'alphazero_model_final.pth'
agent.load_model(model_path)
model = agent.model
model.eval()  # Set the model to evaluation mode

# Wrap the model to return only the policy output
wrapped_model = PolicyModelWrapper(model).to(agent.device)

# Summarize the model architecture
summary(wrapped_model, input_size=(1, 6, 7))

# Convert X_train to a PyTorch tensor with correct dtype and device
X_train_tensor = torch.tensor(X_train, dtype=torch.float32).to(agent.device)

# Create a background dataset for DeepExplainer, typically a subset of X_train
background = X_train_tensor[:100]  # Adjust the number as needed based on your dataset size

# Create the SHAP DeepExplainer using the wrapped model
explainer = shap.DeepExplainer(wrapped_model, background)

# Select a subset of data for explanation to improve performance
data_subset = X_train_tensor[:50]  # Adjust as needed

# Initialize lists to store SHAP values and data
all_shap_values = []
all_data = []

# Loop over each sample
for idx, sample in enumerate(data_subset):
    sample = sample.unsqueeze(0)  # Shape: (1, 1, 6, 7)
    shap_values = explainer.shap_values(sample)  # List of 7 arrays
    
    # Debugging: Print shapes
    print(f"Sample {idx}:")
    for i, sv in enumerate(shap_values):
        print(f"  SHAP values for output {i} shape: {sv.shape}")
    
    # Sum SHAP values over all output classes (axis=0 in the list)
    total_shap_values = np.sum(shap_values, axis=0)          # Sum over outputs list
    total_shap_values = np.sum(total_shap_values, axis=-1)   # Sum over output classes
    
    all_shap_values.append(total_shap_values)
    all_data.append(sample.cpu().numpy())

# Concatenate SHAP values and data
policy_shap_values = np.concatenate(all_shap_values, axis=0)  # Shape: (50, 1, 6, 7)
data_for_plot = np.concatenate(all_data, axis=0)              # Shape: (50, 1, 6, 7)

# Flatten the SHAP values and data for plotting
policy_shap_values = policy_shap_values.reshape(50, -1)  # Shape: (50, 42)
data_for_plot = data_for_plot.reshape(50, -1)            # Shape: (50, 42)

# Print shapes for verification
print(f"Shape of policy_shap_values after reshaping: {policy_shap_values.shape}")
print(f"Shape of data_for_plot after reshaping: {data_for_plot.shape}")

# Define feature names
feature_names = [f"Cell {i}" for i in range(1, 43)]  # 6*7=42 cells

# Plot the SHAP summary plot
shap.summary_plot(policy_shap_values, data_for_plot, feature_names=feature_names)