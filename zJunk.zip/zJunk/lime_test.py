import lime
import lime.lime_tabular
import torch
import numpy as np

# Load your dataset
# Replace with code to load your actual dataset
X_train = np.load('X_train.npy')  # Example: Load from a NumPy file
feature_names = ['feature1', 'feature2', 'feature3', 'feature4']  # Replace with actual feature names
class_names = ['class0', 'class1', 'class2']  # Replace with actual class names

# Define the model architecture matching the saved model
class YourModel(torch.nn.Module):
    def __init__(self):
        super(YourModel, self).__init__()
        self.fc1 = torch.nn.Linear(4, 16)
        self.fc2 = torch.nn.Linear(16, 3)
    
    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# Load the trained model
model = YourModel()
model.load_state_dict(torch.load('alphazero_model_final.pth'))
model.eval()  # Set the model to evaluation mode

# Define the prediction function for LIME
def predict_fn(X):
    X = torch.tensor(X, dtype=torch.float32)
    with torch.no_grad():
        outputs = model(X)
        probabilities = torch.softmax(outputs, dim=1)
        return probabilities.numpy()

# Create the LIME explainer and explain an instance
explainer = lime.lime_tabular.LimeTabularExplainer(
    X_train,
    feature_names=feature_names,
    class_names=class_names,
    mode='classification'
)

# Select an instance to explain
instance = X_train[0]

# Generate explanation
exp = explainer.explain_instance(instance, predict_fn, num_features=5)

# Show the explanation
exp.show_in_notebook()
