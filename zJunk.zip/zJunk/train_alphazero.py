# train_alphazero.py
import logging
import time
from alphazero_agent import AlphaZeroAgent

# Configure logging at the beginning of your script
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(name)s:%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

def train_alphazero(time_limit, load_model=True):
    state_dim = 42  # 6 rows * 7 columns
    action_dim = 7  # Number of columns in Connect Four
    agent = AlphaZeroAgent(state_dim=state_dim, action_dim=action_dim, use_gpu=False)
    
    if load_model:
        try:
            agent.load_model("alphazero_model_final.pth")
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
    
    start_time = time.time()
    while time.time() - start_time < time_limit:
        try:
            # Perform self-play to generate training data
            agent.self_play()
            
            # Perform a training step
            agent.train_step(batch_size=32)
            
            elapsed = time.time() - start_time
            logger.info(f"Elapsed time: {elapsed:.2f}s | Memory Size: {len(agent.memory)}")
        except Exception as e:
            logger.exception(f"An unexpected error occurred during training: {e}")
    
    try:
        agent.save_model("alphazero_model_final.pth")
    except Exception as e:
        logger.error(f"Failed to save model: {e}")

if __name__ == "__main__":
    # Example: Train for 1 hour (3600 seconds)
    train_alphazero(time_limit=3600, load_model=True)