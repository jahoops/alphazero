import torch
import numpy as np
from alphazero_agent import AlphaZeroAgent
from connect4 import Connect4
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def generate_game_states(agent, num_games=100, states_per_game=100):
    game_states = []
    for game in range(1, num_games + 1):
        env = Connect4()
        env.reset()
        state = env.board.copy()
        done = False
        move_count = 0

        logger.info(f"Starting game {game}/{num_games}")
        
        while not done and move_count < states_per_game:
            try:
                action, action_probs = agent.act(state, env, num_simulations=1000)
            except Exception as e:
                logger.error(f"Error during agent.act: {e}")
                break

            legal_moves = env.get_legal_moves()

            if action not in legal_moves:
                logger.warning(f"Illegal move detected: {action}. Skipping game {game}.")
                break

            env.make_move(action)
            game_states.append(state.copy())
            state = env.board.copy()

            winner_id = env.check_winner()
            if winner_id != 0 or env.is_full():
                done = True

            move_count += 1
            if move_count % 10 == 0:
                logger.info(f"Game {game}: Completed {move_count} moves.")

    return np.array(game_states, dtype=np.float32)

def load_model(agent, model_path):
    agent.load_model(model_path)
    return agent.model

if __name__ == "__main__":
    action_dim = 7
    state_dim = 42  # 6 rows x 7 columns
    agent = AlphaZeroAgent(state_dim=state_dim, action_dim=action_dim, use_gpu=False)
    
    # Load the trained model
    model_path = "alphazero_model_final.pth"
    model = load_model(agent, model_path)
    logger.info("Model loaded successfully")
    
    # Generate game states
    X_train = generate_game_states(agent, num_games=5, states_per_game=10)
    
    # Save to 'X_train.npy'
    np.save('X_train.npy', X_train)
    logger.info(f"Generated {len(X_train)} game states and saved to 'X_train.npy'")