from setuptools import setup, Extension

module = Extension(
    'addtwo',
    sources=['addtwo.c'],
    # Include directories are optional; default Python include path is usually sufficient
    include_dirs=[],
    # Libraries are optional; specify if your module depends on external libraries
    libraries=[],
)

setup(
    name='addtwo',
    version='1.0',
    description='A Python module that adds two numbers',
    ext_modules=[module],
)