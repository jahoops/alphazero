import addtwo

result = addtwo.add(3, 5)
print(f"3 + 5 = {result}")