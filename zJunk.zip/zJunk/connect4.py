# connect4.py
import copy
import numpy as np

class Connect4:
    def __init__(self):
        self.board = np.zeros((6, 7), dtype=np.int8)  # 6 rows x 7 columns
        self.current_player = 1  # Player 1 starts

    def clone(self):
        """
        Creates a deep copy of the current game state.
        """
        return copy.deepcopy(self)

    def reset(self):
        """
        Resets the game to the initial state.
        """
        self.board = np.zeros((6, 7), dtype=np.int8)
        self.current_player = 1
        return self.board.copy()

    def make_move(self, action):
        """
        Applies an action to the game state.
        Action represents the column (0-6) where the current player drops a piece.
        """
        for row in range(5, -1, -1):
            if self.board[row][action] == 0:
                self.board[row][action] = self.current_player
                self.current_player = -self.current_player  # Switch player
                break

    def step(self, action):
        """
        Applies an action and returns the new state, reward, done status, and additional info.
        """
        self.make_move(action)
        done = self.is_terminal()
        reward = self.get_reward()
        return self.board.copy(), reward, done, {}

    def is_terminal(self):
        """
        Checks if the game has ended either by win or draw.
        """
        return self.check_win(1) or self.check_win(-1) or self.is_board_full()

    def get_reward(self):
        """
        Returns the reward based on the current game state.
        """
        if self.check_win(1):
            return 1.0
        elif self.check_win(-1):
            return -1.0
        else:
            return 0.0  # Draw or ongoing game

    def get_win_positions(self, player):
        """
        Identifies all winning positions for a given player.
        """
        wins = []
        # Horizontal
        for row in range(6):
            for col in range(4):
                if all(self.board[row, col + i] == player for i in range(4)):
                    wins.append(((row, col), (0, 1)))
        # Vertical
        for col in range(7):
            for row in range(3):
                if all(self.board[row + i, col] == player for i in range(4)):
                    wins.append(((row, col), (1, 0)))
        # Diagonal /
        for row in range(3, 6):
            for col in range(4):
                if all(self.board[row - i, col + i] == player for i in range(4)):
                    wins.append(((row, col), (-1, 1)))
        # Diagonal \
        for row in range(3):
            for col in range(4):
                if all(self.board[row + i, col + i] == player for i in range(4)):
                    wins.append(((row, col), (1, 1)))
        return wins

    def check_win(self, player):
        """
        Checks if the specified player has won the game.
        """
        return len(self.get_win_positions(player)) > 0

    def is_board_full(self):
        """
        Checks if the board is full.
        """
        return not (self.board == 0).any()

    def get_legal_moves(self):
        """
        Returns a list of legal actions (columns that are not full).
        """
        return [col for col in range(7) if self.board[0][col] == 0]

    def get_winner(self):
        """
        Determines the winner of the game.
        """
        if self.check_win(1):
            return 1
        elif self.check_win(-1):
            return -1
        else:
            return 0



