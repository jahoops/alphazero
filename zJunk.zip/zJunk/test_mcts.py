# test_mcts.py
import unittest
from alphazero_agent import MCTSNode, AlphaZeroAgent
from connect4 import Connect4
import numpy as np

class TestMCTSNode(unittest.TestCase):
    def setUp(self):
        self.env = Connect4()
        self.node = MCTSNode(env=self.env.clone())

    def test_expand(self):
        action_probs = np.array([0.1, 0.2, 0.3, 0.4, 0, 0, 0])
        legal_moves = self.env.get_legal_moves()
        self.node.expand(action_probs, legal_moves)
        self.assertEqual(len(self.node.children), len(legal_moves))
        for action in legal_moves:
            self.assertIn(action, self.node.children)
            self.assertAlmostEqual(self.node.children[action].prior, action_probs[action], places=5)

    def test_best_child_no_children(self):
        best = self.node.best_child()
        self.assertIsNone(best)

    def test_best_child_with_children(self):
        action_probs = np.array([0.1, 0.2, 0.3, 0.4, 0, 0, 0])
        legal_moves = self.env.get_legal_moves()
        self.node.expand(action_probs, legal_moves)
        
        total_visits = 0
        for action, child in self.node.children.items():
            child.visits = action + 1  # Assigning arbitrary visit counts (1 to 7)
            child.value = 12.0 if action == 3 else (action + 1) * 1.0  # Higher value for action=3
            total_visits += child.visits
        
        self.node.visits = total_visits  # Update parent node's visits
        
        best = self.node.best_child()
        self.assertIsNotNone(best, "best_child returned None unexpectedly.")
        self.assertEqual(best.visits, 4, "Best child does not have the expected number of visits.")
        self.assertEqual(best.action, 3, "Best child is not the expected action.")

if __name__ == '__main__':
    unittest.main()